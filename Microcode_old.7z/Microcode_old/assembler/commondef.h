#define		NUM_SPECIAL_REG		0xF
#define 	NUM_GEN_IREG		0xF				/* 32 total integer registers - need 5 bits each */

#define	BYTE			unsigned char					/* 8 bits */
#define	SBYTE			signed char
#define	WORD			unsigned short int			/* 16 bits */
#define	DWORD			unsigned int					/* 32 bits */


#define	S1				signed char
#define	U1				unsigned char

#define	S2				signed short int
#define	U2				unsigned short int

#define	S4				signed int
#define	U4				unsigned int


#define	PC 		0
#define	IR 		1
#define	A 		2
#define	B 		3
#define	TDR 	4
#define	MDR 	5
#define	MAR 	6

#define NL				putchar('\n')

