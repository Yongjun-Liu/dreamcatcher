typedef enum{
	JZ,
	JC,
	JMP,
	
	MOV,
	ADD,
	ADC,
	SUB,
	SBB,
	INC,
	DEC,
	AND,
	OR,
	XOR,
	NOT,
	CMP
} _OPCODE;

struct {
	char *mnemonic;
	_OPCODE opcode;
	BYTE len;
} opcodeTable[] = {
	"jz", 		JZ,			2,
	"jc", 		JC,			2,
	"jmp",		JMP,		2,
	
	"mov",		MOV,		2,		
	"add",		ADD,		3,
	"adc",		ADC,		3,
	"sub",		SUB,		3,
	"sbb",		SBB,		3,
	"inc",		INC,		2,
	"dec",		DEC,		2,
	"and", 		AND,		3,
	"or", 		OR,			3,
	"xor", 		XOR,		3,
	"not", 		NOT,		2,
	"cmp", 		CMP,		3,
		
	"", 			-1,		0
};
