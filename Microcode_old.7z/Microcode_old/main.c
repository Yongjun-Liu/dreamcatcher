#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define CONST_LEN 256

enum {	
	SEMICOLON = 1, COLON, COMMA, ANGLES, HASH, TILDE
} tok;

enum {
	DELIMITER = 1,
	INTEGER_CONST,
	STRING_CONST,
	END
} token_type;

typedef enum {
	SYNTAX,
	COMMA_EXPECTED,
	SEMICOLON_EXPECTED,
	COLON_EXPECTED,
	HEX_EXPECTED,
	INSTR_NBR_EXPECTED,
	INTEGER_EXPECTED,
	U_CODE_LENGTH,
	UNTERMINATED_COMMENT,
	COMMA_OR_SEMI_EXPECTED,
	UNFINISHED_ANGLES,
	ANGLES_EXPECTED,
	UNFINISHED_STRING,
	INSTR_NAME_EXPECTED
} _ERROR;

// variable declaration
char *error_table[] = {
	"syntax error",
	"syntax error: comma expected",
	"syntax error: semicolon expected",
	"syntax error: colon expected",
	"hex sign expected",
	"u-instruction number expected",
	"integer expected",
	"exceeded microcode instruction length: max is 64 u-instructions per instruction",
	"unterminated comment",
	"comma or semicolon expected",
	"unfinished angle brackets",
	"angles expected for new instruction declaration",
	"unfinished string",
	"instruction name expected"
};


char token[CONST_LEN + 2]; // string token representation
char *prog; // pointer to the current program position
char *pbuf; // pointer to the beginning of the source code


// functions
char isdelim(char c);
char is_letter(char c);
char is_digit(char c);
unsigned char binstrtoi(char *str);
unsigned char hextoint(char *s);
char isHex(char c);
unsigned char *intToBinStr(char *dest, unsigned char n);
unsigned long int load_program(char *filename);

void get_token(void);
void show_error(_ERROR e);

void putback(void);
void interp_prog(void);

#define MAX_INSTR 256
#define INSTR_LENGTH 64
#define TOTAL_LENGTH (MAX_INSTR * INSTR_LENGTH)

unsigned char u_code1[TOTAL_LENGTH];
unsigned char u_code2[TOTAL_LENGTH];
unsigned char u_code3[TOTAL_LENGTH];
unsigned char u_code4[TOTAL_LENGTH];

char instr_names[MAX_INSTR][CONST_LEN];

unsigned char current_macro_instr = 0; /* this holds the current instruction being processes. also represents the total nbr of instructions processed. */


int main(){
	FILE *fp;
	FILE *fp1, *fp2, *fp3, *fp4;
	char s[9];
	int i, j;
	char key;
	unsigned long int filesize;
	
	printf("Microcode compiler version 1.0\n");
	printf("Written by Paulo Constantino. June 2017\n\n");
	printf("Would you like to compile the microcode now? (Y/N) \n\n");
	key = toupper(getch());
	if(key == 'Y'){
		printf("Loading file: uROM.micro...\n\n");
		filesize = load_program("uROM.micro");
		printf("Total file size in bytes: %d\n\n", filesize);
		prog = pbuf;
		printf("Compiling file...\n\n");
		interp_prog();
		free(pbuf);
		
		printf("Generating ROM images...\n\n");
		fp = fopen("ROM1.bin", "w+b");
		if(fp == NULL){
			printf("Unable to create file. Press any key to quit.");
			getch();
			return 1;
		}
		fwrite(u_code1, sizeof(unsigned char), TOTAL_LENGTH, fp);
		fclose(fp);
		
		fp = fopen("ROM2.bin", "w+b");
		if(fp == NULL){
			printf("Unable to create file. Press any key to quit.");
			getch();
			return 1;
		}
		fwrite(u_code2, sizeof(unsigned char), TOTAL_LENGTH, fp);
		fclose(fp);
		
		fp = fopen("ROM3.bin", "w+b");
		if(fp == NULL){
			printf("Unable to create file. Press any key to quit.");
			getch();
			return 1;
		}
		fwrite(u_code3, sizeof(unsigned char), TOTAL_LENGTH, fp);
		fclose(fp);
		
		fp = fopen("ROM4.bin", "w+b");
		if(fp == NULL){
			printf("Unable to create file. Press any key to quit.");
			getch();
			return 1;
		}
		fwrite(u_code4, sizeof(unsigned char), TOTAL_LENGTH, fp);
		fclose(fp);
		
		printf("ROM images generated with success.\n\n\n");
		printf("Comparing generated images with original file...");
		
		fp1 = fopen("ROM1.bin", "rb");
		fp2 = fopen("ROM2.bin", "rb");
		fp3 = fopen("ROM3.bin", "rb");
		fp4 = fopen("ROM4.bin", "rb");
		
		if(fp1 == NULL || fp2 == NULL || fp3 == NULL || fp4 == NULL){
			printf("Unable to open generated files to check their validity. Press any key to continue.");
			getch();
		}
	
	/* checking if the written binary file is equal to the compiled file. */
		unsigned char temp;
		for(i = 0; i < TOTAL_LENGTH; i++){
			fread(&temp, 1, 1, fp1);
			if(temp != u_code1[i]){
				printf("Error: generated binary file differs from compiled file.");
				getch();
			}
			fread(&temp, 1, 1, fp2);
			if(temp != u_code2[i]){
				printf("Error: generated binary file differs from compiled file.");
				getch();
			}
			fread(&temp, 1, 1, fp3);
			if(temp != u_code3[i]){
				printf("Error: generated binary file differs from compiled file.");
				getch();
			}
			fread(&temp, 1, 1, fp4);
			if(temp != u_code4[i]){
				printf("Error: generated binary file differs from compiled file.");
				getch();
			}
		}
		fclose(fp1);
		fclose(fp2);
		fclose(fp3);
		fclose(fp4);
		
		printf("OK\n\n");
		
		printf("u-instruction size: %d bytes, i.e. 64 clock cycles max per instruction.\n\n", INSTR_LENGTH);
	
		int len1=0, len2=0, len3=0, len4=0;
		float average_cpi = 0.0;
		printf("List of compiled instructions...\n\n");
		printf("XX:XX >> instruction code(hex) and total number of clocks(dec), i.e. u-instruction length.\n\n");
		for(i = 0; i < current_macro_instr; i += 4){
			if(i % 64 == 0) puts("");  
			if((i < current_macro_instr))
				for(j = INSTR_LENGTH * i; j < INSTR_LENGTH * i + INSTR_LENGTH; j++){
					if((j - INSTR_LENGTH * (i)) == INSTR_LENGTH - 1){
						printf("\n\nFatal error on last u-instruction of \"%s\". Instruction type field is not 10(fetch). Machine code: %X\n\n", instr_names[i], i);
						printf("Press any key to continue...\n\n");
						getch();
					}
					if(((u_code1[j] & 0x02) == 0x02) && ( ((u_code1[j] & 0x01) == 0x00) || ((u_code1[j] & 0x01) == 0x01)  ) ){
						len1 = j - INSTR_LENGTH * i + 1;
						average_cpi += len1;
						break;
					}
				}
			if((i + 1 < current_macro_instr))
				for(j = INSTR_LENGTH * (i+1); j < INSTR_LENGTH * (i+1) + INSTR_LENGTH; j++){
					if((j - INSTR_LENGTH * (i+1)) == INSTR_LENGTH - 1){
						printf("\n\nFatal error on last u-instruction of \"%s\". Instruction type field is not 10(fetch). Machine code: %X\n\n", instr_names[i + 1], i + 1);
						printf("Press any key to continue...\n\n");
						getch();
					}
					if(((u_code1[j] & 0x02) == 0x02) && ( ((u_code1[j] & 0x01) == 0x00) || ((u_code1[j] & 0x01) == 0x01) )){
						len2 = j - INSTR_LENGTH * (i+1) + 1;
						average_cpi += len2;
						break;
					}
				}
			if((i + 2 < current_macro_instr))
				for(j = INSTR_LENGTH * (i+2); j < INSTR_LENGTH * (i+2) + INSTR_LENGTH; j++){
					if((j - INSTR_LENGTH * (i+2)) == INSTR_LENGTH - 1){
						printf("\n\nFatal error on last u-instruction of \"%s\". Instruction type field is not 10(fetch). Machine code: %X\n\n", instr_names[i + 2], i + 2);
						printf("Press any key to continue...\n\n");
						getch();
					}
					if(((u_code1[j] & 0x02) == 0x02) && ( ((u_code1[j] & 0x01) == 0x00) || ((u_code1[j] & 0x01) == 0x01)  ) ){
						len3 = j - INSTR_LENGTH * (i+2) + 1;
						average_cpi += len3;
						break;
					}
				}
			if((i + 3 < current_macro_instr))
				for(j = INSTR_LENGTH * (i+3); j < INSTR_LENGTH * (i+3) + INSTR_LENGTH; j++){
					if((j - INSTR_LENGTH * (i+3)) == INSTR_LENGTH - 1){
						printf("\n\nFatal error on last u-instruction of \"%s\". Instruction type field is not 10(fetch). Machine code: %X\n\n", instr_names[i + 3], i + 3);
						printf("Press any key to continue...\n\n");
						getch();
					}
					if(((u_code1[j] & 0x02) == 0x02) && ( ((u_code1[j] & 0x01) == 0x00) || ((u_code1[j] & 0x01) == 0x01) ) ){
						len4 = j - INSTR_LENGTH * (i+3) + 1;
						average_cpi += len4;
						break;
					}
				}
			
			printf("%02X:%02d> %-30s %02X:%02d> %-30s %02X:%02d> %-30s %02X:%02d> %-30s\n", 
				i, len1, instr_names[i], i + 1, len2, instr_names[i + 1], i + 2, len3, instr_names[i + 2], i + 3, len4, instr_names[i + 3]);
		}
		
		float freq = 5000000.0;
		average_cpi = average_cpi / current_macro_instr;
		printf("\n\nEnter the clock frequency in Hz> ");
		scanf("%f", &freq);
		printf("\n\n>>>> Average clocks per instruction: %.2f\n\n", average_cpi);
		printf("%.3fHz clock period: %.3f ns\n\n", freq, (1.0 / freq) * 1000000000.0 );
		printf("Average instruction period at %.3fHz: %.3f us\n\n", freq, (1.0 / freq) * 1000000.0 * average_cpi);
		
		puts("");
		
		printf("Would you like to see the contents of the compiled binary files ? (Y/N) \n\n");
		char choice = getch();
		
		if(toupper(choice) == 'Y'){
			fp1 = fopen("ROM1.bin", "rb");
			fp2 = fopen("ROM2.bin", "rb");
			fp3 = fopen("ROM3.bin", "rb");
			fp4 = fopen("ROM4.bin", "rb");
			
			if(fp1 == NULL || fp2 == NULL || fp3 == NULL || fp4 == NULL){
				printf("Unable to open generated files to check their validity. Press any key to continue.");
				getch();
			}
			
			printf("        ROM1             ROM2             ROM3             ROM4\n\n");
			s[8] = '\0';
		
			for(i = 0; i <= current_macro_instr; i++){
				printf("0x%02X: (%s) \n", i, instr_names[i]);
				for(j = 0; j < INSTR_LENGTH; j++){
					printf("%02X::%02X: ", 	i * INSTR_LENGTH + j, j);
					fread(&temp, 1, 1, fp1);
					printf("0x%02X:%s    ", temp, intToBinStr(s, temp));
					fread(&temp, 1, 1, fp2);
					printf("0x%02X:%s    ", temp, intToBinStr(s, temp));
					fread(&temp, 1, 1, fp3);
					printf("0x%02X:%s    ", temp, intToBinStr(s, temp));
					fread(&temp, 1, 1, fp4);
					printf("0x%02X:%s\n", 	temp, intToBinStr(s, temp));
				}
				printf("\n\n");
			}
			
			fclose(fp1);
			fclose(fp2);
			fclose(fp3);
			fclose(fp4);
		}
	
		printf("Microcode compiled successfully.\n\n");
		printf("Total number of macro instructions: %d(0x%02X)\n\n", current_macro_instr + 1, current_macro_instr + 1);
		printf("Press any key to exit.");
		getch();
		
	}
	else{
		printf("Microcode not compiled. Press any key to exit.");
		getch();	
	}
	
	return 0;
}

unsigned char *intToBinStr(char *dest, unsigned char n){
	if(n & 0x80) dest[0] = '1'; else dest[0] = '0';
	if(n & 0x40) dest[1] = '1'; else dest[1] = '0';
	if(n & 0x20) dest[2] = '1'; else dest[2] = '0';
	if(n & 0x10) dest[3] = '1'; else dest[3] = '0';
	if(n & 0x08) dest[4] = '1'; else dest[4] = '0';
	if(n & 0x04) dest[5] = '1'; else dest[5] = '0';
	if(n & 0x02) dest[6] = '1';	else dest[6] = '0';
	if(n & 0x01) dest[7] = '1'; else dest[7] = '0';
	
	return dest;
}

unsigned long int load_program(char *filename){
	FILE *fp;
	unsigned long int filesize;
	char temp;
	
	if((fp = fopen(filename, "rb")) == NULL){
		printf("program source file not found");
		exit(0);
	}
	
	/* get file size */
	filesize = 0;
	while(!feof(fp)){
		fread(&temp, 1, 1, fp);
		filesize++;	
	}
	
	filesize += 10;
	
	if((pbuf = malloc(filesize)) == NULL){
		printf("failed to allocate memory for the program source");
		exit(0);
	}
	
	prog = pbuf;
	
	rewind(fp);	
	do{
		fread(prog, 1, 1, fp);
		prog++;
	} while(!feof(fp));
	
	fclose(fp);
	
	if(*(prog - 2) == 0x1A) *(prog - 2) = '\0';
	else *(prog - 1) = '\0';
	
	return filesize - 10;
}

void interp_prog(){	
	unsigned char current_micro;
	unsigned char block = 0;
	
	get_token();
	do{
		if(tok != ANGLES) show_error(ANGLES_EXPECTED);
		get_token();
		if(token_type != STRING_CONST) show_error(INSTR_NAME_EXPECTED);
		strcpy(instr_names[current_macro_instr], token);
		
		current_micro = 0;
		do{
			if(current_micro >= INSTR_LENGTH) show_error(U_CODE_LENGTH);
			/* rom1 */
			get_token();
			if(token_type != INTEGER_CONST) show_error(INTEGER_EXPECTED);
			block = binstrtoi(token);
			u_code1[current_macro_instr * INSTR_LENGTH + current_micro] = block;
			get_token();
			if(tok != COMMA) show_error(COMMA_EXPECTED);
			
			/* rom2 */
			get_token();
			if(token_type != INTEGER_CONST) show_error(INTEGER_EXPECTED);
			block = binstrtoi(token);
			u_code2[current_macro_instr * INSTR_LENGTH + current_micro] = block;
			get_token();
			if(tok != COMMA) show_error(COMMA_EXPECTED);
			
			/* rom3 */
			get_token();
			if(token_type != INTEGER_CONST) show_error(INTEGER_EXPECTED);
			block = binstrtoi(token);
			u_code3[current_macro_instr * INSTR_LENGTH + current_micro] = block;
			get_token();
			if(tok != COMMA) show_error(COMMA_EXPECTED);
			
			/* rom4 */
			get_token();
			if(token_type != INTEGER_CONST) show_error(INTEGER_EXPECTED);
			block = binstrtoi(token);
			u_code4[current_macro_instr * INSTR_LENGTH + current_micro] = block;
			get_token(); // get token type but puts back since will be used again if number or angles
			if(token_type != INTEGER_CONST && tok != ANGLES && tok != '\0') show_error(SYNTAX);
			putback();
			current_micro++; /* next micro */
			
		} while(token_type == INTEGER_CONST); /* repeat until finds semicolon: end of u-instruction */
		
		get_token();				
		if(tok == ANGLES) current_macro_instr++;
		
	} while(tok == ANGLES);
}

unsigned char binstrtoi(char *str){
	int i;
	unsigned char n = 0;
	for(i = 0; i < 8; i++){
		if(str[i] == '1') n = n + (unsigned char)pow(2, 7 - i);
	}
	return (unsigned char)n;
}

void putback(void){
	char *t = token;
	while(*t++) prog--;
}

unsigned char hextoint(char *s){
	unsigned char n = 0;
	
	switch(toupper(s[0])){
		case '0': n = n + 0; break;
		case '1': n = n + 1 * 16; break;
		case '2': n = n + 2 * 16; break;
		case '3': n = n + 3 * 16; break;
		case '4': n = n + 4 * 16; break;
		case '5': n = n + 5 * 16; break;
		case '6': n = n + 6 * 16; break;
		case '7': n = n + 7 * 16; break;
		case '8': n = n + 8 * 16; break;
		case '9': n = n + 9 * 16; break;
		case 'A': n = n + 10 * 16; break;
		case 'B': n = n + 11 * 16; break;
		case 'C': n = n + 12 * 16; break;
		case 'D': n = n + 13 * 16; break;
		case 'E': n = n + 14 * 16; break;
		case 'F': n = n + 15 * 16; break;
	}
	
	switch(toupper(s[1])){
		case '0': n = n + 0; break;
		case '1': n = n + 1; break;
		case '2': n = n + 2; break;
		case '3': n = n + 3; break;
		case '4': n = n + 4; break;
		case '5': n = n + 5; break;
		case '6': n = n + 6; break;
		case '7': n = n + 7; break;
		case '8': n = n + 8; break;
		case '9': n = n + 9; break;
		case 'A': n = n + 10; break;
		case 'B': n = n + 11; break;
		case 'C': n = n + 12; break;
		case 'D': n = n + 13; break;
		case 'E': n = n + 14; break;
		case 'F': n = n + 15; break;
	}
	
	return n;
}

void show_error(_ERROR e){
	int line = 1;
	char *t = pbuf;

	puts(error_table[e]);
	
	while(t < prog){
		t++;
		if(*t == '\n') line++;
	}
	
	printf("line number: %d\n", line);
	printf("near: %s", token);
	system("pause");

	exit(0);
}

void get_token(void){
	char *t;
	// skip blank spaces

	*token = '\0';
	tok = 0;
	t = token;
	
	do{
		while(isspace(*prog) || *prog == '\n') prog++;

		if(*prog == '*'){
			prog++;
			while(*prog != '*'){
				prog++;
				if(!*prog) show_error(UNTERMINATED_COMMENT);
				
			}
			prog++;
		}
		else if(*prog == ';'){
			prog++;
			while(*prog != 0x0D) prog++;
			prog++;
			if(*prog == 0x0A) prog++;			
		}
	} while(isspace(*prog) || *prog == '*' || *prog == ';');
	

	if(*prog == '\0'){
		token_type = END;
		return;
	}
	
	if(is_digit(*prog)){
		if(*(prog + 1) == 'x'){
			prog = prog + 2;
			while(is_digit(*prog)) *t++ = *prog++;
			
		}
		else
			while(is_digit(*prog)) *t++ = *prog++;
		token_type = INTEGER_CONST;
	}
	else if(isdelim(*prog)){
		if(*prog == ':'){
			*t++ = *prog++;
			tok = COLON;
			token_type = DELIMITER;
		}
		else if(*prog == ','){
			*t++ = *prog++;
			tok = COMMA;
			token_type = DELIMITER;
		}
		else if(*prog == '>'){
			*t++ = *prog++;
			if(*prog != '>') show_error(UNFINISHED_ANGLES);
			else *t++ = *prog++;
			tok = ANGLES;
			token_type = DELIMITER;
		}
		else if(*prog == '\"'){
			prog++;
			while(*prog != '\"' && *prog != '\0') *t++ = *prog++;
			if(*prog != '\"') show_error(UNFINISHED_STRING);
			prog++;
			token_type = STRING_CONST;
		}
	}

	*t = '\0';
}

char isHex(char c){
	char a = tolower(c);
	return a == 'a' || a == 'b' || a == 'c' || a == 'd' || a == 'e' || a == 'f';
}

char is_digit(char c){
	return (c >= '0' && c <= '9') || (c >= 'A' && c <= 'F') || (c >= 'a' && c <= 'f');	
};

char isdelim(char c){
	if(strchr(";:,x>\"#", c)) return 1;
	else return 0;
}

char is_letter(char c){
	return(isalpha(c));
}

