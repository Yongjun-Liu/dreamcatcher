//---------------------------------------------------------------------------

#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <vcl.h>
#include <math.h>
#pragma hdrstop

#include "sim.h"
#include "class.cpp"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "CGAUGES"
#pragma resource "*.dfm"
Tfmain *fmain;



#define PIN_DIM 20; // pixels
#define ID_LEN 64
#define TOTAL_CONTROL_BITS 17 * 8
#define MAX_CYCLES_PER_INSTR 16
#define TOTAL_INSTRUCTIONS 500
                               
#define CONTROL_WORD_FILE_LENGTH 3000

void get_token(void);

enum { IDENTIFIER, END } token_type;

char token[ID_LEN];          

class CONTROL_BIT{
	public:
    	DWORD id;
    	char name[ID_LEN];
        
} control_bits[TOTAL_CONTROL_BITS]; // this keeps a list of all control bits used in the CPU

class CONTROLBIT_VAL : public CONTROL_BIT{
	public:
        BYTE value;
};

class CYCLE{
	public:
    	CONTROLBIT_VAL control_bit[TOTAL_CONTROL_BITS];
};



class INSTRUCTION{
	public:
        WORD opcode;
    	char mnemonic[ID_LEN];
        WORD nbr_cycles;																																																								
        CYCLE cycle[MAX_CYCLES_PER_INSTR];
        
};



INSTRUCTION instructions[TOTAL_INSTRUCTIONS];

const DWORD GRID_SIZE = 10;
const MAX_COMPONENT_PINS = 32;

const DWORD NUM_GEN_REG = 8;
const DWORD NUM_SPEC_REG = 4;
const DWORD MAX_NETS = 100;
const DWORD MAX_COMPONENTS = 100;

enum VALUE {zero, one, highz, xx};
enum PINtype {input, output};

enum TOOL {tool_net, tool_component};

class net{
	public:
    	DWORD id;
        VALUE val;

        TPoint p1, p2;	// screen coordinates
};

/*
			 ________
  IN1	----|        |
  IN2  	----|  GATE  |------- OUTPUT NET
  IN3  	----|________|

*/



class PIN{
	public:
        DWORD netid;	/* what net is this attached to ? */
        PINtype type;
        VALUE val;      // pin value
        DWORD xoffset, yoffset;
};

class COMPONENT{
	public:
    	DWORD id;
        TPoint coord;
        Graphics::TBitmap *bmp;
        DWORD width, height;
        BYTE nbr_pins;
        PIN pins[MAX_COMPONENT_PINS];
};

net nets[MAX_NETS];
DWORD net_index = 0;
COMPONENT components[MAX_COMPONENTS];
DWORD comp_index = 0;

Graphics::TBitmap *screen;

TOOL tool;
TPoint screen_coord;

BYTE CLK = 0;
DWORD elapsed_time;

bool clicked;


char control_file[CONTROL_WORD_FILE_LENGTH];
char *file_pointer;




__fastcall Tfmain::Tfmain(TComponent* Owner)
	: TForm(Owner)
{
}

String ValToStr(VALUE val){
    String s;
    
	switch(val){
     	case zero:
     		s = "zero";
            break;
        case one:
        	s = "one";
            break;
        case highz:
        	s = "High Z";
        	break;
        case xx:
        	s = "XX";
            break;
        default:
        	s = "err";
    }
    return s;
}

void __fastcall Tfmain::Button1Click(TObject *Sender)
{
	tool = tool_net;
}






void __fastcall Tfmain::formscreenMouseDown(TObject *Sender,
      TMouseButton Button, TShiftState Shift, int X, int Y)
{
	register DWORD i, j;

	switch(tool){
        case tool_net:
        	if(clicked == true){
            	prompt->Lines->Append("Added net: " + IntToStr(net_index));
            	nets[net_index].p2.x = screen_coord.x;
                nets[net_index].p2.y = screen_coord.y;
                nets[net_index].val = one;
                net_index++;
                clicked = false;
            }
            else{
            	nets[net_index].id = net_index;
              	nets[net_index].val = xx;
              	nets[net_index].p1.x = screen_coord.x;
              	nets[net_index].p1.y = screen_coord.y;
				clicked = true;
            }

            break;
        case tool_component:
            components[comp_index].id = comp_index;
            components[comp_index].coord = screen_coord;
            components[comp_index].width = 40;
            components[comp_index].height = 30;
            comp_index++;
            break;
    }



}



void update_system(){
	register TPoint i, j, k;

}

void __fastcall Tfmain::Timer1Timer(TObject *Sender)
{
	DWORD i;
    TPoint coord;

    
    coord = Mouse->CursorPos;

    screen->Canvas->FillRect(Rect(0, 0, screen->Width, screen->Height));
    
    for(i = 0; i < net_index; i++){
    	screen->Canvas->MoveTo(nets[i].p1.x, nets[i].p1.y);
    	screen->Canvas->LineTo(nets[i].p2.x, nets[i].p2.y);
        screen->Canvas->TextOut((nets[i].p1.x + nets[i].p2.x)/2, (nets[i].p1.y + nets[i].p2.y)/2, "id:" + IntToStr(nets[i].id));
        screen->Canvas->TextOut((nets[i].p1.x + nets[i].p2.x)/2, (nets[i].p1.y + nets[i].p2.y)/2 + 15, "val: " + ValToStr(nets[i].val));

    }
    for(i = 0; i < comp_index; i++){
        screen->Canvas->Rectangle(Rect(components[i].coord.x, components[i].coord.y, components[i].coord.x + components[i].width, components[i].coord.y + components[i].height));
    }

    if(clicked == true){
    	screen->Canvas->MoveTo(nets[net_index].p1.x, nets[net_index].p1.y);
    }
    else{
    	screen->Canvas->MoveTo(screen_coord.x, screen_coord.y);
    }
    
    screen->Canvas->LineTo(screen_coord.x, screen_coord.y);
    
    formscreen->Canvas->Draw(0, 0, screen);		
}



void __fastcall Tfmain::formscreenMouseMove(TObject *Sender,
      TShiftState Shift, int X, int Y)
{
	screen_coord.x = floor(X / GRID_SIZE) * GRID_SIZE;
    screen_coord.y = floor(Y / GRID_SIZE) * GRID_SIZE;
}


void prompt_out(char *msg){
	fmain->edit_compiler_out->Lines->Append(msg);
}

void __fastcall Tfmain::FormActivate(TObject *Sender)
{
	register DWORD i, j, k;
    FILE *fp;
	String s;


    screen = new Graphics::TBitmap;
    screen->Width = formscreen->Width;
    screen->Height = formscreen->Height;

	screen->Canvas->Pen->Width = 2;
    screen->Canvas->Brush->Color = clBlack;
    screen->Canvas->Pen->Color = RGB(0, 255, 0);
    screen->Canvas->Font->Color = RGB(0, 255, 0);

    
    if((fp = fopen("control_word.txt", "rb")) == NULL){
    	prompt_out("Unable to open control word declaration file");
    }
    else{
        file_pointer = control_file;

        while(!feof(fp)){
            *file_pointer = getc(fp);
            file_pointer++;
        }
        if(*(file_pointer - 2) == 0x1A)
        	*(file_pointer - 2) = '\0';
		else
        	*(file_pointer - 1) = '\0';

        fclose(fp);

        prompt_out("Control word file read with success.\n");

        file_pointer = control_file;
        for(i = 0; i < TOTAL_CONTROL_BITS; i++){
        	control_bits[i].id = i;
            get_token();
			strcpy(control_bits[i].name, token);
            s = IntToStr(i) + " : " + token;            
            prompt_out(s.c_str());

            bit_list->Items->Append(token);
        }                 


    }






	
}









void __fastcall Tfmain::Timer2Timer(TObject *Sender)
{
	if(CLK == 0){
    	CLK = 1;
    }
    else{
    	CLK = 0;
    }
    
    elapsed_time++;

    imgscope->Canvas->Brush->Color = clBlack;
    imgscope->Canvas->Pen->Color = RGB(0, 255, 0);
    imgscope->Canvas->FillRect(Rect(0, 0, imgscope->Width, imgscope->Height));

    imgscope->Canvas->MoveTo(imgscope->Width / 2, CLK * imgscope->Height / 2);
    imgscope->Canvas->LineTo(imgscope->Width, CLK * imgscope->Height / 2);


    prompt->Lines->Append("Elapsed time: " + IntToStr(elapsed_time));

	update_system();	
}


void __fastcall Tfmain::SpeedButton2Click(TObject *Sender)
{
	if(Timer2->Enabled == true)
    	Timer2->Enabled = false;
    else
    	Timer2->Enabled = true;
}



void new_component(){

}


void get_token(void){
	char *t;
	// skip blank spaces

	*token = '\0';
	t = token;

	while(isspace(*file_pointer) || *file_pointer == '\n') file_pointer++;

	if(*file_pointer == '\0'){
		token_type = END;
		return;
	}


	if(isalpha(*file_pointer)){
		while(isalpha(*file_pointer) || isdigit(*file_pointer) || *file_pointer == '_')
			*t++ = *file_pointer++;
		token_type = IDENTIFIER;
	}



	*t = '\0';
}







