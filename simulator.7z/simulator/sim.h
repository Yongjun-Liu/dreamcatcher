//---------------------------------------------------------------------------

#ifndef simH
#define simH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <Grids.hpp>
#include <ComCtrls.hpp>
#include <Menus.hpp>
#include <Buttons.hpp>
#include <ToolWin.hpp>
#include <Graphics.hpp>
#include <CheckLst.hpp>
#include <ValEdit.hpp>
#include "CGAUGES.h"
#include <Outline.hpp>
#include <FileCtrl.hpp>
#include <OleCtnrs.hpp>
//---------------------------------------------------------------------------
class Tfmain : public TForm
{
__published:	// IDE-managed Components
	TMainMenu *MainMenu1;
	TMenuItem *File1;
	TMenuItem *Edit1;
	TMenuItem *Tools1;
	TMenuItem *Information1;
	TMenuItem *About1;
	TTimer *Timer1;
	TTimer *Timer2;
	TMenuItem *View1;
	TMenuItem *DigitalSimulator1;
	TMenuItem *CPUSimulator1;
	TMenuItem *uCodeCompiler1;
	TPopupMenu *instruction_popup;
	TMenuItem *Insert1;
	TMenuItem *NewCycle1;
	TMenuItem *DeleteCycle1;
	TPopupMenu *cycle_popup;
	TMenuItem *MenuItem1;
	TMenuItem *MenuItem2;
	TMenuItem *MenuItem3;
	TStatusBar *StatusBar1;
	TToolBar *ToolBar1;
	TPageControl *PageControl1;
	TTabSheet *TabSheet1;
	TGroupBox *GroupBox1;
	TRichEdit *prompt;
	TGroupBox *GroupBox4;
	TPaintBox *formscreen;
	TGroupBox *GroupBox3;
	TImage *imgscope;
	TPageControl *PageControl2;
	TTabSheet *TabSheet3;
	TToolBar *ToolBar2;
	TButton *Button1;
	TToolBar *ToolBar3;
	TSpeedButton *SpeedButton2;
	TToolBar *ToolBar4;
	TStatusBar *StatusBar2;
	TTabSheet *TabSheet2;
	TTabSheet *TabSheet4;
	TGroupBox *GroupBox2;
	TGroupBox *GroupBox9;
	TButton *Button4;
	TButton *Button5;
	TButton *Button7;
	TButton *Button10;
	TButton *Button6;
	TButton *Button8;
	TButton *Button9;
	TButton *Button11;
	TButton *Button12;
	TButton *Button13;
	TButton *Button14;
	TButton *Button15;
	TButton *Button16;
	TButton *Button17;
	TGroupBox *GroupBox7;
	TLabeledEdit *LabeledEdit1;
	TButton *Button2;
	TButton *Button3;
	TGroupBox *GroupBox8;
	TGroupBox *GroupBox5;
	TCheckListBox *bit_list;
	TGroupBox *GroupBox6;
	TListBox *ListBox1;
	TTabSheet *TabSheet5;
	TProgressBar *ProgressBar1;
	TSpeedButton *SpeedButton1;
	TSpeedButton *SpeedButton3;
	TSpeedButton *SpeedButton4;
	TSpeedButton *SpeedButton5;
	TSpeedButton *SpeedButton6;
	TToolButton *ToolButton1;
	TSpeedButton *SpeedButton7;
	TSpeedButton *SpeedButton8;
	TRichEdit *edit_compiler_in;
	TRichEdit *edit_compiler_out;
	TListBox *ListBox2;
	void __fastcall Button1Click(TObject *Sender);
	void __fastcall formscreenMouseDown(TObject *Sender, TMouseButton Button,
          TShiftState Shift, int X, int Y);
	void __fastcall Timer1Timer(TObject *Sender);
	void __fastcall formscreenMouseMove(TObject *Sender, TShiftState Shift,
          int X, int Y);
	void __fastcall FormActivate(TObject *Sender);
	void __fastcall Timer2Timer(TObject *Sender);
	void __fastcall SpeedButton2Click(TObject *Sender);
private:	// User declarations
public:		// User declarations
	__fastcall Tfmain(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE Tfmain *fmain;
//---------------------------------------------------------------------------
#endif
